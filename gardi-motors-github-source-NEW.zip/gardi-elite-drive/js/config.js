/**
 * Site configuration. Fill contact methods in before publishing.
 * Do not put private credentials or API keys in frontend code.
 */
export const SITE = {
  brandName: 'Gardi Motors',
  label: 'Elite Drive',
  country: 'Ghana',
  // Digits only, with country code. Example formatting: 233XXXXXXXXX (not a real number).
  whatsapp: '',
  // Public business email if applicable. Leave blank otherwise.
  email: '',
  telephone: '',
  // Optional: a real Google Maps link once your public showroom address is confirmed.
  mapUrl: '',
  instagram: '',
  tiktok: '',
};
